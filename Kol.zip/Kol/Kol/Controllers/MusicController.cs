﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Kol.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MusicController : ControllerBase
    {

        private readonly IDbService _dbService;
        public MusicController(IDbService musicController)
        {
            _dbService = musicController;
        }

        [HttpGet]
        public async Task<IActionResult> GetZamowienia(int albumId)
        {
            try
            {
                return Ok(await _dbService.GetAlbum(albumId));
            }
            catch (System.Exception)
            {
                return Conflict();
            }

        }
    }

}