﻿using Kol.Models.DTO;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Kol.Services
{
    public class DbService : IDbService
    {
        private readonly MainDbContext _context;
        public DbService(MainDbContext context)
        {
            _context = context;
        }/*
        public async Task<IEnumerable<GetAlbum>> GetAlbum(int albumId)
        {
            
            return await _context.Albums.Where(e => e.IdAlbum == albumId)
                    .Select(e => new Album
                    {
                        AlbumName = e.AlbumName,
                        PublishDate = e.PublishDate,

                        *Tracks = e.Tracks.Select(e => new GetAlbum
                        {
                            TrackName = e.Tr.Nazwa,
                            CenaZaSzt = e.WyrobCukierniczy.CenaZaSzt,
                            Typ = e.WyrobCukierniczy.Typ,
                            Ilosc = e.Ilosc,
                            Uwagi = e.Uwagi
                        })
                        
                    }).ToListAsync();
    }
        */
        public Task<IEnumerable<GetAlbum>> GetAlbum(int albumId)
        {
            throw new NotImplementedException();
        }
    }
}