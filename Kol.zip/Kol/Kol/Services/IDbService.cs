﻿using System;
using Kol.Models.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Kol
{
    public interface IDbService
    {
        Task<IEnumerable<GetAlbum>> GetAlbum(int albumId);
    }
}
