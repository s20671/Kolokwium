﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kol.Models.DTO
{
    public class GetAlbum
    {
        public string AlbumName  { get; set; }
        public DateTime? PublishDate { get; set; }
        public Track Track { get; set; }
        public virtual ICollection<Track> Tracks { get; set; }
    }
}
