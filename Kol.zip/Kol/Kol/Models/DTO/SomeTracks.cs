﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Kol.Models.DTO
{
    public class SomeTracks
    {
        public string TrackName { get; set; }
        public float Duration { get; set; }
    }
}
