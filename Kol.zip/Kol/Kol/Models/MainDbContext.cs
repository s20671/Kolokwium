﻿using Microsoft.EntityFrameworkCore;
using System;

namespace Kol
{
    public partial class MainDbContext : DbContext
    {
        public MainDbContext()
        {
        }

        public MainDbContext(DbContextOptions options) : base(options) {    }
        public DbSet<Album> Albums { get; set; }
        public DbSet<Track> Tracks { get; set; }
        public DbSet<Musician> Musicians { get; set; }
        public DbSet<Musician_Track> Musician_Tracks { get; set; }
        public DbSet<MusicLabel> MusicLabels { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        { base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Musician_Track>().HasKey(e => new { e.IdMusician, e.IdTrack });
            modelBuilder.Entity<Musician_Track>().HasOne(e => e.Musician)
                .WithMany(m => m.Musician_Track)
                .HasForeignKey(m => m.IdMusician)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Musician_Track>().HasOne(e => e.Track)
                .WithMany(m => m.Musician_Track)
                .HasForeignKey(m => m.IdTrack)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Track>().HasOne(e => e.Album)
                .WithMany(m => m.Tracks)
                .HasForeignKey(m => m.IdMusicAlbum)
                .OnDelete(DeleteBehavior.Restrict);
            modelBuilder.Entity<Album>().HasOne(e => e.MusicLabel)
                .WithMany(m => m.Albums)
                .HasForeignKey(m => m.IdMusicLabel)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Musician>().HasData(
                new Musician() { IdMusician = 1, FirstName = "Mathew", LastName = "Krutel",NickName="chojwoj" },
                new Musician() { IdMusician = 2, FirstName = "Wojciech", LastName = "Chjak", NickName = "Dragon" }
                );

            modelBuilder.Entity<Track>().HasData(
                new Track() { IdTrack = 1, TrackName = "TrackStar", Duration = 3, IdMusicAlbum = 1},
                new Track() { IdTrack = 2, TrackName = "PopStar", Duration = 4, IdMusicAlbum = 2 }

                );

            modelBuilder.Entity<Album>().HasData(
                new Album() { IdAlbum = 1, AlbumName = "Rocket", PublishDate = DateTime.Now, IdMusicLabel = 1},
                new Album() { IdAlbum = 2, AlbumName = "SomethingLose" , PublishDate = DateTime.Now, IdMusicLabel = 1}

                );

            modelBuilder.Entity<MusicLabel>().HasData(
                new MusicLabel() { IdMusicLabel = 1, Name = "Otschodzi"}
                );
            modelBuilder.Entity<Musician_Track>().HasData(
                new Musician_Track() { IdTrack = 1, IdMusician = 1 },
                new Musician_Track() { IdTrack = 2, IdMusician = 2 }
                );
        }
    }
}
